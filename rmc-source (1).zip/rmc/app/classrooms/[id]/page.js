"use client";

import { useEffect, useState } from "react";
import Shell, { Avatar } from "../../../components/Shell";
import { api } from "../../../lib/client";

export default function ClassroomDetail({ params }) {
  const [data, setData] = useState(null);
  const [form, setForm] = useState({ title: "", body: "", link: "", fileName: "" });
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const res = await api("classroom", { id: params.id });
    setData(res.error ? { error: res.error } : res);
  }
  useEffect(() => { load(); }, [params.id]);

  async function act(action) {
    const res = await api(action, { id: params.id });
    if (res.error) return setError(res.error);
    load();
  }

  async function post(e) {
    e.preventDefault();
    const res = await api("post", { classroomId: params.id, ...form });
    if (res.error) return setError(res.error);
    setForm({ title: "", body: "", link: "", fileName: "" });
    load();
  }

  async function sendComment(postId) {
    const res = await api("comment", { postId, body: comment });
    if (res.error) return setError(res.error);
    setComment("");
    load();
  }

  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;
  if (data.error) return <Shell><p>{data.error}</p></Shell>;
  const c = data.classroom;

  return (
    <Shell>
      <section className="card overflow-hidden">
        <div className="relative h-40" style={{ background: c.cover.startsWith("linear") ? c.cover : undefined }}>
          {!c.cover.startsWith("linear") && <img src={c.cover} alt="" className="h-full w-full object-cover" />}
          {c.logo && <img src={c.logo} alt="" className="absolute bottom-3 left-4 h-16 w-16 rounded-2xl border-4 border-white object-cover" />}
        </div>
        <div className="p-5">
          <div className="text-xs text-slate-500">{c.grade} · ដោយ {c.owner?.displayName}</div>
          <h1 className="font-display text-3xl font-bold">{c.name}</h1>
          <p className="mt-2 text-slate-600 dark:text-slate-300">{c.description}</p>
          <div className="mt-3 text-sm">👥 {c.memberCount} សមាជិក · ♥ {c.likeCount} · 💬 {c.commentCount}</div>
          <div className="mt-4 flex gap-2">
            <button className="btn-primary" onClick={() => act("join")}>{c.joined ? "ចាកចេញ" : "ចូលរួម"}</button>
            <button className="btn-ghost" onClick={() => act("like")}>{c.liked ? "ដកចិត្ត" : "ចូលចិត្ត"}</button>
          </div>
          {error && <p className="mt-2 text-sm text-rose-500">{error}</p>}
        </div>
      </section>

      <form onSubmit={post} className="card mt-4 space-y-2 p-4">
        <h2 className="font-semibold">ចែកមេរៀន ឯកសារ ឬតំណ</h2>
        <input className="field" placeholder="ចំណងជើង" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <textarea className="field" placeholder="ការពិពណ៌នា" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
        <input className="field" placeholder="តំណ (វីដេអូ / PDF)" value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })} />
        <input className="text-sm" type="file" accept=".pdf,.doc,.docx,image/*" onChange={(e) => setForm({ ...form, fileName: e.target.files?.[0]?.name || "" })} />
        {form.fileName && <p className="text-xs">ឯកសារ៖ {form.fileName} (រក្សាឈ្មោះសម្រាប់ចែករំលែកក្នុងថ្នាក់)</p>}
        <button className="btn-primary">ផុសក្នុងថ្នាក់</button>
      </form>

      <div className="mt-4 space-y-3">
        {data.posts.map((p) => (
          <article key={p.id} className="card p-4">
            <div className="flex items-center gap-2 text-sm"><Avatar user={p.author} /> <b>{p.author?.displayName}</b></div>
            <h3 className="mt-2 font-semibold">{p.title}</h3>
            <p className="mt-1 whitespace-pre-wrap text-sm">{p.body}</p>
            {p.fileName && <p className="mt-1 text-xs">📎 {p.fileName}</p>}
            {p.link && <a className="mt-1 block text-sm text-indigo-600 underline dark:text-amber-300" href={p.link} target="_blank" rel="noreferrer">{p.link}</a>}
            <div className="mt-3 space-y-2">
              {p.comments.map((cm) => (
                <div key={cm.id} className="rounded-2xl bg-slate-100 px-3 py-2 text-sm dark:bg-white/5">
                  <b>{cm.author?.displayName}</b> · {cm.body}
                </div>
              ))}
              <div className="flex gap-2">
                <input className="field" placeholder="មតិយោបល់" value={comment} onChange={(e) => setComment(e.target.value)} />
                <button className="btn-ghost" onClick={() => sendComment(p.id)}>ផ្ញើ</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Shell>
  );
}
