"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function ClassroomsPage() {
  const [rooms, setRooms] = useState([]);
  useEffect(() => { api("classrooms").then((d) => setRooms(d.classrooms || [])); }, []);
  return (
    <Shell>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold">ថ្នាក់ និងសាលានិម្មិត</h1>
          <p className="text-sm text-slate-500">ចូលរួម ចូលចិត្ត និងចែកមេរៀន។</p>
        </div>
        <Link href="/classrooms/new" className="btn-primary">បង្កើតថ្នាក់</Link>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {rooms.map((c) => (
          <Link key={c.id} href={`/classrooms/${c.id}`} className="card overflow-hidden">
            <div className="relative h-28" style={{ background: c.cover.startsWith("linear") ? c.cover : undefined }}>
              {!c.cover.startsWith("linear") && <img src={c.cover} alt="" className="h-full w-full object-cover" />}
              {c.logo && <img src={c.logo} alt="" className="absolute bottom-2 left-3 h-12 w-12 rounded-2xl border-2 border-white object-cover" />}
            </div>
            <div className="p-4">
              <div className="text-xs text-slate-500">{c.grade}</div>
              <h2 className="text-lg font-semibold">{c.name}</h2>
              <p className="mt-1 line-clamp-2 text-sm text-slate-500">{c.description}</p>
              <div className="mt-2 text-xs">👥 {c.memberCount} · ♥ {c.likeCount} · 💬 {c.commentCount}</div>
            </div>
          </Link>
        ))}
      </div>
    </Shell>
  );
}
