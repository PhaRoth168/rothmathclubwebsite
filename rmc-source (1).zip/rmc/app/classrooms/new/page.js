"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Shell from "../../../components/Shell";
import { api, fileToData } from "../../../lib/client";

export default function NewClassroom() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", grade: "", description: "", cover: "", logo: "" });
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    const res = await api("createClass", form);
    if (res.error) return setError(res.error);
    router.push(`/classrooms/${res.classroom.id}`);
  }

  return (
    <Shell>
      <form onSubmit={submit} className="mx-auto max-w-xl card space-y-3 p-6">
        <h1 className="font-display text-3xl font-bold text-blue-950 dark:text-white">បង្កើតថ្នាក់រៀន</h1>
        <p className="text-sm text-slate-500">មានតែគ្រូ ឬ Admin ប៉ុណ្ណោះ។ កម្រិតថ្នាក់សរសេរដោយសេរី។</p>
        <input className="field" placeholder="ឈ្មោះថ្នាក់" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="field" placeholder="កម្រិតថ្នាក់ ឧ. ថ្នាក់ទី១២ ក, Bac II, Olympiad" value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} />
        <textarea className="field min-h-28" placeholder="ការពិពណ៌នា" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <label className="block text-sm">Logo ថ្នាក់
          <input className="mt-1 block" type="file" accept="image/*" onChange={async (e) => {
            try { setForm({ ...form, logo: await fileToData(e.target.files[0], 280000) }); setError(""); }
            catch { setError("Logo ធំពេក"); }
          }} />
        </label>
        <label className="block text-sm">រូបគម្រប
          <input className="mt-1 block" type="file" accept="image/*" onChange={async (e) => {
            try { setForm({ ...form, cover: await fileToData(e.target.files[0], 500000) }); setError(""); }
            catch { setError("រូបគម្របធំពេក"); }
          }} />
        </label>
        <div className="flex items-center gap-3">
          {form.logo && <img src={form.logo} alt="" className="h-14 w-14 rounded-2xl object-cover" />}
          {form.cover && <img src={form.cover} alt="" className="h-14 flex-1 rounded-2xl object-cover" />}
        </div>
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button className="btn-primary">បង្កើត</button>
      </form>
    </Shell>
  );
}
