"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function NotificationsPage() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    api("notifications").then((d) => setItems(d.notifications || []));
    api("readNotes");
  }, []);
  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">ដំណឹង</h1>
      <div className="mt-4 space-y-2">
        {items.length === 0 && <p className="text-sm text-slate-500">មិនទាន់មានដំណឹង។</p>}
        {items.map((n) => (
          <Link key={n.id} href={n.href || "/"} className="card block p-4">
            <div className="font-medium">{n.text}</div>
            <div className="text-xs text-slate-400">{new Date(n.createdAt).toLocaleString()}</div>
          </Link>
        ))}
      </div>
    </Shell>
  );
}
