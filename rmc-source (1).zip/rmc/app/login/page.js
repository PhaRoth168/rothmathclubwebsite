"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function LoginPage() {
  return (
    <Shell>
      <AuthCard mode="login" />
    </Shell>
  );
}

export function AuthCard({ mode }) {
  const router = useRouter();
  const [form, setForm] = useState({ displayName: "", email: "", password: "", grade: "ថ្នាក់ទី១២", role: "student" });
  const [error, setError] = useState("");
  const [googleOpen, setGoogleOpen] = useState(false);

  async function submit(e) {
    e.preventDefault();
    const data = await api(mode === "login" ? "login" : "signup", form);
    if (data.error) return setError(data.error);
    router.push("/profile");
    router.refresh();
  }

  async function google(e) {
    e.preventDefault();
    const data = await api("google", { email: form.email, displayName: form.displayName || form.email.split("@")[0] });
    if (data.error) return setError(data.error);
    router.push("/profile");
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-md card p-6">
      <h1 className="font-display text-3xl font-bold">{mode === "login" ? "ចូលគណនី" : "ចុះឈ្មោះ"}</h1>
      <p className="mt-1 text-sm text-slate-500">គណនីសាកល្បង៖ admin@rothmath.club / admin123 ឬ rathana@student.rmc / math123</p>
      <form onSubmit={submit} className="mt-5 space-y-3">
        {mode === "signup" && <input className="field" placeholder="ឈ្មោះបង្ហាញ" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />}
        <input className="field" type="email" placeholder="អ៊ីមែល" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input className="field" type="password" placeholder="ពាក្យសម្ងាត់" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        {mode === "signup" && (
          <>
            <input className="field" placeholder="កម្រិតថ្នាក់ ឧ. ថ្នាក់ទី១២ ក" value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <button type="button" className={form.role === "student" ? "btn-primary" : "btn-ghost"} onClick={() => setForm({ ...form, role: "student" })}>សិស្ស</button>
              <button type="button" className={form.role === "teacher" ? "btn-primary" : "btn-ghost"} onClick={() => setForm({ ...form, role: "teacher" })}>គ្រូ / ម្ចាស់ថ្នាក់</button>
            </div>
          </>
        )}
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button className="btn-primary w-full">{mode === "login" ? "ចូល" : "បង្កើតគណនី"}</button>
      </form>
      <button className="btn-ghost mt-3 w-full" onClick={() => setGoogleOpen((v) => !v)}>បន្តជាមួយ Google</button>
      {googleOpen && (
        <form onSubmit={google} className="mt-3 space-y-2 rounded-2xl bg-slate-100 p-3 text-sm dark:bg-white/5">
          <p>សម្រាប់ដាក់ដំណើរការពិត សូមដាក់ Google OAuth Client ID។ ឥឡូវនេះបញ្ចូលអ៊ីមែល Google ដើម្បីបង្កើតសម័យសាកល្បង។</p>
          <input className="field" placeholder="ឈ្មោះ" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
          <input className="field" type="email" placeholder="you@gmail.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <button className="btn-primary w-full">ចូលតាម Google</button>
        </form>
      )}
    </div>
  );
}
