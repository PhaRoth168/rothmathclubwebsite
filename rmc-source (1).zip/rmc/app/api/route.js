const {
  withDb, sign, readSession, publicUser, badgesFor, hashPassword, verifyPassword,
  id, touchStreak, decorateQuestion, decorateClassroom, leaderboards, notify, TOPICS, GRADES, dayKey
} = require("../../lib/store");

function cookieHeader(token) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `rmc_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${secure}`;
}

function clearCookie() {
  return "rmc_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0";
}

function tokenFrom(req) {
  const raw = req.headers.get("cookie") || "";
  const part = raw.split(";").map((s) => s.trim()).find((s) => s.startsWith("rmc_session="));
  return part ? decodeURIComponent(part.split("=").slice(1).join("=")) : "";
}

function me(db, req) {
  const userId = readSession(tokenFrom(req));
  return db.users.find((u) => u.id === userId) || null;
}

function profileOf(db, user) {
  const base = publicUser(user);
  base.badges = badgesFor(user, db);
  base.questionCount = db.questions.filter((q) => q.userId === user.id).length;
  base.answerCount = db.answers.filter((a) => a.userId === user.id).length;
  base.unread = db.notifications.filter((n) => n.userId === user.id && !n.read).length;
  return base;
}

async function handle(req) {
  const body = req.method === "GET" ? {} : await req.json().catch(() => ({}));
  const action = body.action || new URL(req.url).searchParams.get("action") || "bootstrap";

  return withDb((db) => {
    const user = me(db, req);

    if (action === "bootstrap") {
      const today = dayKey();
      return {
        user: user ? profileOf(db, user) : null,
        topics: TOPICS,
        grades: GRADES,
        today,
        stats: {
          members: db.users.length,
          questions: db.questions.length,
          classrooms: db.classrooms.length,
          puzzles: db.puzzles.length
        },
        puzzle: db.puzzles.find((p) => p.day === today) || null,
        topClassrooms: db.classrooms.map((c) => decorateClassroom(db, c, user && user.id)).sort((a, b) => b.score - a.score).slice(0, 3),
        recentQuestions: db.questions.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4).map((q) => decorateQuestion(db, q))
      };
    }

    if (action === "signup") {
      const email = String(body.email || "").trim().toLowerCase();
      const displayName = String(body.displayName || "").trim();
      const password = String(body.password || "");
      if (!email || !displayName || password.length < 6) return { error: "សូមបំពេញឈ្មោះ អ៊ីមែល និងពាក្យសម្ងាត់យ៉ាងតិច ៦ តួ។" };
      if (db.users.some((u) => u.email === email)) return { error: "អ៊ីមែលនេះមានរួចហើយ។" };
      const created = {
        id: id("u"),
        displayName,
        email,
        passwordHash: hashPassword(password),
        role: body.role === "teacher" ? "teacher" : "student",
        grade: body.grade || "ថ្នាក់ទី១០",
        bio: "",
        avatar: "",
        provider: "email",
        streak: 1,
        longestStreak: 1,
        lastActiveDay: dayKey(),
        points: 10,
        createdAt: new Date().toISOString()
      };
      db.users.push(created);
      touchStreak(db, created.id, "signup");
      return { user: profileOf(db, created), token: sign(created.id) };
    }

    if (action === "login") {
      const email = String(body.email || "").trim().toLowerCase();
      const found = db.users.find((u) => u.email === email);
      if (!found || !verifyPassword(body.password || "", found.passwordHash)) return { error: "អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ។" };
      touchStreak(db, found.id, "login");
      return { user: profileOf(db, found), token: sign(found.id) };
    }

    if (action === "google") {
      const email = String(body.email || "").trim().toLowerCase();
      const displayName = String(body.displayName || "សិស្ស Google").trim();
      if (!email || !email.includes("@")) return { error: "សូមបញ្ចូលអ៊ីមែល Google។" };
      let found = db.users.find((u) => u.email === email);
      if (!found) {
        found = {
          id: id("u"),
          displayName,
          email,
          passwordHash: hashPassword(id("g")),
          role: body.role === "teacher" ? "teacher" : "student",
          grade: body.grade || "ថ្នាក់ទី១១",
          bio: "ចូលតាម Google",
          avatar: "",
          provider: "google",
          streak: 1,
          longestStreak: 1,
          lastActiveDay: dayKey(),
          points: 10,
          createdAt: new Date().toISOString()
        };
        db.users.push(found);
      }
      touchStreak(db, found.id, "google");
      return { user: profileOf(db, found), token: sign(found.id) };
    }

    if (action === "logout") return { ok: true, clear: true };

    if (!user && ["profile", "ask", "answer", "vote", "createClass", "join", "like", "post", "comment", "puzzleAttempt", "savePuzzle", "ping", "readNotes"].includes(action)) {
      return { error: "សូមចូលគណនីជាមុន។" };
    }

    if (action === "ping" && user) {
      touchStreak(db, user.id, "visit");
      return { user: profileOf(db, user) };
    }

    if (action === "profile") {
      if (body.displayName) user.displayName = String(body.displayName).trim().slice(0, 40);
      if (typeof body.bio === "string") user.bio = body.bio.slice(0, 240);
      if (body.grade) user.grade = body.grade;
      if (typeof body.avatar === "string") {
        if (body.avatar.length > 350000) return { error: "រូបធំពេក។ សូមប្រើរូបតូចជាង 250KB។" };
        user.avatar = body.avatar;
      }
      touchStreak(db, user.id, "profile");
      return { user: profileOf(db, user) };
    }

    if (action === "questions") {
      let list = db.questions.slice();
      if (body.topic) list = list.filter((q) => q.topic === body.topic);
      if (body.grade) list = list.filter((q) => q.grade === body.grade);
      if (body.q) {
        const s = String(body.q).toLowerCase();
        list = list.filter((q) => (q.title + q.body).toLowerCase().includes(s));
      }
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      return { questions: list.map((q) => decorateQuestion(db, q)) };
    }

    if (action === "question") {
      const q = db.questions.find((item) => item.id === body.id);
      if (!q) return { error: "រកមិនឃើញសំណួរ។" };
      return { question: decorateQuestion(db, q) };
    }

    if (action === "ask") {
      const title = String(body.title || "").trim();
      const text = String(body.body || "").trim();
      if (title.length < 4 || text.length < 4) return { error: "សូមសរសេរចំណងជើង និងសំណួរឱ្យច្បាស់។" };
      if (body.image && body.image.length > 500000) return { error: "រូបលំហាត់ធំពេក។" };
      const q = {
        id: id("q"),
        userId: user.id,
        title: title.slice(0, 140),
        body: text.slice(0, 2000),
        topic: body.topic || "ពីជគណិត",
        grade: body.grade || user.grade,
        image: body.image || "",
        createdAt: new Date().toISOString()
      };
      db.questions.unshift(q);
      touchStreak(db, user.id, "ask");
      user.points += 8;
      return { question: decorateQuestion(db, q) };
    }

    if (action === "answer") {
      const q = db.questions.find((item) => item.id === body.questionId);
      if (!q) return { error: "រកមិនឃើញសំណួរ។" };
      const text = String(body.body || "").trim();
      if (text.length < 2 && !body.image) return { error: "សូមសរសេរចម្លើយ ឬភ្ជាប់រូប។" };
      if (body.image && body.image.length > 500000) return { error: "រូបធំពេក។" };
      const answer = {
        id: id("a"),
        questionId: q.id,
        userId: user.id,
        body: text.slice(0, 2000),
        image: body.image || "",
        createdAt: new Date().toISOString()
      };
      db.answers.push(answer);
      touchStreak(db, user.id, "answer");
      user.points += 10;
      if (q.userId !== user.id) notify(db, q.userId, `${user.displayName} បានឆ្លើយសំណួររបស់អ្នក`, `/questions/${q.id}`);
      return { question: decorateQuestion(db, q) };
    }

    if (action === "vote") {
      const answer = db.answers.find((a) => a.id === body.answerId);
      if (!answer) return { error: "រកមិនឃើញចម្លើយ។" };
      const value = body.value === -1 ? -1 : 1;
      const existing = db.votes.find((v) => v.userId === user.id && v.answerId === answer.id);
      if (existing && existing.value === value) db.votes = db.votes.filter((v) => v !== existing);
      else if (existing) existing.value = value;
      else db.votes.push({ id: id("vote"), userId: user.id, answerId: answer.id, value, createdAt: new Date().toISOString() });
      touchStreak(db, user.id, "vote");
      if (value === 1 && answer.userId !== user.id) notify(db, answer.userId, `${user.displayName} បានបោះឆ្នោតឱ្យចម្លើយរបស់អ្នក`, `/questions/${answer.questionId}`);
      const q = db.questions.find((item) => item.id === answer.questionId);
      return { question: decorateQuestion(db, q) };
    }

    if (action === "classrooms") {
      return { classrooms: db.classrooms.map((c) => decorateClassroom(db, c, user && user.id)).sort((a, b) => b.score - a.score) };
    }

    if (action === "classroom") {
      const c = db.classrooms.find((item) => item.id === body.id);
      if (!c) return { error: "រកមិនឃើញថ្នាក់។" };
      const posts = db.posts.filter((p) => p.classroomId === c.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map((p) => ({
        ...p,
        author: publicUser(db.users.find((u) => u.id === p.userId)),
        comments: db.comments.filter((cm) => cm.postId === p.id).map((cm) => ({
          ...cm,
          author: publicUser(db.users.find((u) => u.id === cm.userId))
        }))
      }));
      return { classroom: decorateClassroom(db, c, user && user.id), posts };
    }

    if (action === "createClass") {
      if (user.role !== "teacher" && user.role !== "admin") return { error: "មានតែគ្រូ ឬ Admin ប៉ុណ្ណោះដែលបង្កើតថ្នាក់បាន។" };
      const name = String(body.name || "").trim();
      const grade = String(body.grade || "").trim();
      if (name.length < 3) return { error: "សូមដាក់ឈ្មោះថ្នាក់។" };
      if (grade.length < 1) return { error: "សូមសរសេរកម្រិតថ្នាក់។" };
      if ((body.logo || "").length > 400000 || (body.cover || "").length > 700000) return { error: "រូបធំពេក។" };
      const c = {
        id: id("c"),
        name: name.slice(0, 60),
        grade: grade.slice(0, 40),
        description: String(body.description || "").slice(0, 400),
        cover: body.cover || "linear-gradient(135deg,#1d4ed8,#38bdf8)",
        logo: body.logo || "",
        ownerId: user.id,
        createdAt: new Date().toISOString()
      };
      db.classrooms.unshift(c);
      db.members.push({ id: id("mem"), classroomId: c.id, userId: user.id, createdAt: new Date().toISOString() });
      touchStreak(db, user.id, "class");
      user.points += 12;
      return { classroom: decorateClassroom(db, c, user.id) };
    }

    if (action === "join") {
      const c = db.classrooms.find((item) => item.id === body.id);
      if (!c) return { error: "រកមិនឃើញថ្នាក់។" };
      const exists = db.members.find((m) => m.classroomId === c.id && m.userId === user.id);
      if (exists) db.members = db.members.filter((m) => m !== exists);
      else {
        db.members.push({ id: id("mem"), classroomId: c.id, userId: user.id, createdAt: new Date().toISOString() });
        if (c.ownerId !== user.id) notify(db, c.ownerId, `${user.displayName} បានចូលថ្នាក់ ${c.name}`, `/classrooms/${c.id}`);
      }
      touchStreak(db, user.id, "join");
      return { classroom: decorateClassroom(db, c, user.id) };
    }

    if (action === "like") {
      const c = db.classrooms.find((item) => item.id === body.id);
      if (!c) return { error: "រកមិនឃើញថ្នាក់។" };
      const exists = db.likes.find((l) => l.classroomId === c.id && l.userId === user.id);
      if (exists) db.likes = db.likes.filter((l) => l !== exists);
      else {
        db.likes.push({ id: id("like"), classroomId: c.id, userId: user.id, createdAt: new Date().toISOString() });
        if (c.ownerId !== user.id) notify(db, c.ownerId, `${user.displayName} បានចូលចិត្តថ្នាក់ ${c.name}`, `/classrooms/${c.id}`);
      }
      touchStreak(db, user.id, "like");
      return { classroom: decorateClassroom(db, c, user.id) };
    }

    if (action === "post") {
      const c = db.classrooms.find((item) => item.id === body.classroomId);
      if (!c) return { error: "រកមិនឃើញថ្នាក់។" };
      const joined = db.members.some((m) => m.classroomId === c.id && m.userId === user.id);
      if (!joined) return { error: "សូមចូលរួមថ្នាក់ជាមុន។" };
      const title = String(body.title || "").trim();
      if (title.length < 2) return { error: "សូមដាក់ចំណងជើងឯកសារ ឬមេរៀន។" };
      db.posts.unshift({
        id: id("p"),
        classroomId: c.id,
        userId: user.id,
        title: title.slice(0, 120),
        body: String(body.body || "").slice(0, 1500),
        link: String(body.link || "").slice(0, 300),
        fileName: String(body.fileName || "").slice(0, 80),
        createdAt: new Date().toISOString()
      });
      touchStreak(db, user.id, "post");
      user.points += 6;
      return { ok: true };
    }

    if (action === "comment") {
      const post = db.posts.find((p) => p.id === body.postId);
      if (!post) return { error: "រកមិនឃើញប្រកាស។" };
      const text = String(body.body || "").trim();
      if (text.length < 1) return { error: "សូមសរសេរមតិ។" };
      db.comments.push({ id: id("cc"), postId: post.id, userId: user.id, body: text.slice(0, 800), createdAt: new Date().toISOString() });
      touchStreak(db, user.id, "comment");
      if (post.userId !== user.id) notify(db, post.userId, `${user.displayName} បានមតិលើប្រកាសរបស់អ្នក`, `/classrooms/${post.classroomId}`);
      return { ok: true };
    }

    if (action === "puzzles") {
      const list = db.puzzles.slice().sort((a, b) => b.day.localeCompare(a.day)).map((p) => ({
        ...p,
        attempts: db.attempts.filter((t) => t.puzzleId === p.id).length,
        solved: user ? db.attempts.some((t) => t.puzzleId === p.id && t.userId === user.id && t.correct) : false,
        mine: user ? db.attempts.find((t) => t.puzzleId === p.id && t.userId === user.id) : null
      }));
      return { puzzles: list, today: dayKey() };
    }

    if (action === "puzzleAttempt") {
      const puzzle = db.puzzles.find((p) => p.id === body.puzzleId);
      if (!puzzle) return { error: "រកមិនឃើញសំណួរ។" };
      const already = db.attempts.find((t) => t.puzzleId === puzzle.id && t.userId === user.id);
      if (already) return { correct: already.correct, explanation: puzzle.explanation, already: true };
      const correct = String(body.choice) === String(puzzle.answer);
      db.attempts.push({ id: id("try"), puzzleId: puzzle.id, userId: user.id, correct, createdAt: new Date().toISOString() });
      touchStreak(db, user.id, "puzzle");
      if (correct) user.points += 15;
      return { correct, explanation: puzzle.explanation };
    }

    if (action === "deletePuzzle") {
      if (!user || user.role !== "admin") return { error: "មានតែ Admin ប៉ុណ្ណោះ។" };
      db.puzzles = db.puzzles.filter((p) => p.id !== body.id);
      return { ok: true };
    }

    if (action === "savePuzzle") {
      if (user.role !== "admin") return { error: "មានតែ Admin ប៉ុណ្ណោះ។" };
      const prompt = String(body.prompt || "").trim();
      const choices = (body.choices || []).map((c) => String(c).trim()).filter(Boolean);
      if (prompt.length < 4 || choices.length < 2 || !body.answer) return { error: "សូមបំពេញសំណួរ ជម្រើស និងចម្លើយ។" };
      const puzzle = {
        id: id("pz"),
        title: String(body.title || "Daily Challenge").slice(0, 80),
        prompt,
        choices,
        answer: String(body.answer),
        explanation: String(body.explanation || "").slice(0, 500),
        topic: body.topic || "ពីជគណិត",
        grade: body.grade || "ថ្នាក់ទី១២",
        day: body.day || dayKey(),
        createdBy: user.id,
        createdAt: new Date().toISOString()
      };
      db.puzzles.unshift(puzzle);
      return { puzzle };
    }

    if (action === "leaderboards") return leaderboards(db, body.period || "all");

    if (action === "notifications") {
      if (!user) return { notifications: [] };
      return { notifications: db.notifications.filter((n) => n.userId === user.id).slice(0, 40) };
    }

    if (action === "readNotes") {
      db.notifications.forEach((n) => {
        if (n.userId === user.id) n.read = true;
      });
      return { ok: true };
    }

    if (action === "admin") {
      if (!user || user.role !== "admin") return { error: "មានតែ Admin ប៉ុណ្ណោះ។" };
      return {
        users: db.users.map((u) => profileOf(db, u)),
        puzzles: db.puzzles
      };
    }

    if (action === "myActivity") {
      if (!user) return { error: "សូមចូលគណនីជាមុន។" };
      return {
        user: profileOf(db, user),
        questions: db.questions.filter((q) => q.userId === user.id).map((q) => decorateQuestion(db, q)),
        answers: db.answers.filter((a) => a.userId === user.id).length
      };
    }

    return { error: "សកម្មភាពមិនស្គាល់។" };
  });
}

function respond(result) {
  const headers = { "Content-Type": "application/json" };
  if (result && result.token) headers["Set-Cookie"] = cookieHeader(result.token);
  if (result && result.clear) headers["Set-Cookie"] = clearCookie();
  return new Response(JSON.stringify(result), { status: 200, headers });
}

export async function GET(req) {
  return respond(await handle(req));
}

export async function POST(req) {
  return respond(await handle(req));
}
