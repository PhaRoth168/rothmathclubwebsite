"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell, { Avatar } from "../../components/Shell";
import { api, fileToData } from "../../lib/client";

export default function ProfilePage() {
  const [data, setData] = useState(null);
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    api("myActivity").then((d) => {
      setData(d);
      if (d.user) setForm({ displayName: d.user.displayName, bio: d.user.bio || "", grade: d.user.grade, avatar: d.user.avatar || "" });
    });
  }, []);

  async function save(e) {
    e.preventDefault();
    const res = await api("profile", form);
    setMsg(res.error || "បានរក្សាទុក");
    if (res.user) setData((d) => ({ ...d, user: res.user }));
  }

  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;
  if (!data.user) return <Shell><p>សូម <Link className="underline" href="/login">ចូលគណនី</Link> ដើម្បីមើលប្រូហ្វាល់។</p></Shell>;
  const user = data.user;

  return (
    <Shell>
      <div className="grid gap-4 md:grid-cols-[.8fr_1.2fr]">
        <section className="card p-5">
          <div className="flex items-center gap-3">
            <Avatar user={{ ...user, avatar: form.avatar }} size="h-16 w-16" />
            <div>
              <h1 className="font-display text-2xl font-bold">{user.displayName}</h1>
              <p className="text-sm text-slate-500">{user.grade} · {user.email}</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-amber-100 p-3 dark:bg-amber-400/10"><div className="text-2xl">🔥 {user.streak}</div><div className="text-xs">Streak</div></div>
            <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/5"><div className="text-2xl">{user.answerCount}</div><div className="text-xs">ចម្លើយ</div></div>
            <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/5"><div className="text-2xl">{user.questionCount}</div><div className="text-xs">សំណួរ</div></div>
          </div>
          <p className="mt-4 text-sm text-slate-600 dark:text-slate-300">{user.bio || "មិនទាន់មានប្រវត្តិរូបសង្ខេប។"}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {user.badges.map((b) => <span key={b.id} className="chip">{b.icon} {b.name}</span>)}
          </div>
        </section>
        <section className="card p-5">
          <h2 className="font-display text-xl font-bold">កែប្រូហ្វាល់</h2>
          <form onSubmit={save} className="mt-4 space-y-3">
            <input className="field" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
            <textarea className="field min-h-24" placeholder="ប្រវត្តិរូបសង្ខេប" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
            <input className="field" placeholder="កម្រិតថ្នាក់" value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} />
            <label className="block text-sm">រូបតំណាង
              <input className="mt-1 block text-sm" type="file" accept="image/*" onChange={async (e) => {
                try { setForm({ ...form, avatar: await fileToData(e.target.files[0], 250000) }); }
                catch { setMsg("រូបធំពេក"); }
              }} />
            </label>
            {msg && <p className="text-sm">{msg}</p>}
            <button className="btn-primary">រក្សាទុក</button>
          </form>
        </section>
      </div>
      <section className="mt-6">
        <h2 className="mb-3 font-display text-2xl font-bold">សំណួរដែលខ្ញុំបានផុស</h2>
        <div className="space-y-3">
          {data.questions.length === 0 && <p className="text-sm text-slate-500">មិនទាន់មានសំណួរ។</p>}
          {data.questions.map((q) => (
            <Link key={q.id} href={`/questions/${q.id}`} className="card block p-4">
              <div className="font-semibold">{q.title}</div>
              <div className="text-sm text-slate-500">{q.topic} · {q.answerCount} ចម្លើយ</div>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
