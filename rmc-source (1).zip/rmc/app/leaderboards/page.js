"use client";

import { useEffect, useState } from "react";
import Shell, { Avatar } from "../../components/Shell";
import { api } from "../../lib/client";

const tabs = [
  ["answerers", "អ្នកឆ្លើយពូកែ"],
  ["classrooms", "ថ្នាក់ពូកែ"],
  ["streaks", "Streak ខ្ពស់"],
  ["active", "អ្នកសកម្ម"]
];

export default function LeaderboardsPage() {
  const [tab, setTab] = useState("answerers");
  const [period, setPeriod] = useState("all");
  const [q, setQ] = useState("");
  const [data, setData] = useState(null);
  useEffect(() => { api("leaderboards", { period }).then(setData); }, [period]);
  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;

  const rows = (data[tab] || []).filter((r) => (r.displayName || r.name || "").toLowerCase().includes(q.toLowerCase()));

  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">តារាងចំណាត់ថ្នាក់ពេញលេញ</h1>
      <p className="mt-1 text-sm text-slate-500">បញ្ជីទាំងអស់ មិនមែនតែ Top 10 ទេ។</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {[["daily", "ប្រចាំថ្ងៃ"], ["weekly", "ប្រចាំសប្តាហ៍"], ["monthly", "ប្រចាំខែ"], ["all", "ទាំងអស់"]].map(([id, label]) => (
          <button key={id} className={period === id ? "btn-primary" : "btn-ghost"} onClick={() => setPeriod(id)}>{label}</button>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {tabs.map(([id, label]) => (
          <button key={id} className={tab === id ? "btn-primary" : "btn-ghost"} onClick={() => setTab(id)}>{label}</button>
        ))}
      </div>
      <input className="field mt-4" placeholder="ស្វែងរកឈ្មោះ" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="card mt-4 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="text-slate-500">
            <tr>
              <th className="p-3">#</th><th className="p-3">ឈ្មោះ</th>
              {tab === "answerers" && <><th>ចម្លើយល្អ</th><th>សំឡេង</th><th>ចម្លើយ</th></>}
              {tab === "classrooms" && <><th>សមាជិក</th><th>ចូលចិត្ត</th><th>មតិ</th><th>ពិន្ទុ</th></>}
              {tab === "streaks" && <><th>Streak</th><th>វែងបំផុត</th></>}
              {tab === "active" && <><th>ពិន្ទុ</th><th>សកម្មភាព</th><th>សំណួរ</th><th>ចម្លើយ</th></>}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.id} className="border-t border-slate-100 dark:border-white/10">
                <td className="p-3 font-display">{i + 1}</td>
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    {tab !== "classrooms" && <Avatar user={r} />}
                    <div>
                      <div className="font-semibold">{r.displayName || r.name}</div>
                      <div className="text-xs text-slate-400">{r.grade}</div>
                    </div>
                  </div>
                </td>
                {tab === "answerers" && <><td>{r.best}</td><td>{r.votes}</td><td>{r.answers}</td></>}
                {tab === "classrooms" && <><td>{r.memberCount}</td><td>{r.likeCount}</td><td>{r.commentCount}</td><td>{r.score}</td></>}
                {tab === "streaks" && <><td>🔥 {r.streak}</td><td>{r.longestStreak}</td></>}
                {tab === "active" && <><td>{r.points}</td><td>{r.actions}</td><td>{r.questions}</td><td>{r.answers}</td></>}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="p-4 text-sm text-slate-500">មិនមានទិន្នន័យ។</p>}
      </div>
    </Shell>
  );
}
