"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api, fileToData } from "../../lib/client";

export default function AskPage() {
  const router = useRouter();
  const [meta, setMeta] = useState({ topics: [], grades: [] });
  const [form, setForm] = useState({ title: "", body: "", topic: "ពីជគណិត", grade: "ថ្នាក់ទី១២", image: "" });
  const [error, setError] = useState("");

  useEffect(() => { api("bootstrap").then((d) => setMeta(d)); }, []);

  async function submit(e) {
    e.preventDefault();
    const res = await api("ask", form);
    if (res.error) return setError(res.error);
    router.push(`/questions/${res.question.id}`);
  }

  return (
    <Shell>
      <form onSubmit={submit} className="mx-auto max-w-2xl card space-y-3 p-6">
        <h1 className="font-display text-3xl font-bold">ផុសសំណួរ</h1>
        <input className="field" placeholder="ចំណងជើងលំហាត់" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <textarea className="field min-h-32" placeholder="ពិពណ៌នាអ្វីដែលជាប់គាំង។ អាចសរសេររូបមន្តដូច x^2-5x+6=0" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
        <div className="grid gap-2 md:grid-cols-2">
          <select className="field" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })}>{meta.topics.map((t) => <option key={t}>{t}</option>)}</select>
          <select className="field" value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })}>{meta.grades.map((g) => <option key={g}>{g}</option>)}</select>
        </div>
        <label className="text-sm">រូបលំហាត់
          <input className="mt-1 block" type="file" accept="image/*" onChange={async (e) => {
            try { setForm({ ...form, image: await fileToData(e.target.files[0]) }); setError(""); }
            catch { setError("រូបធំពេក"); }
          }} />
        </label>
        {form.image && <img src={form.image} alt="" className="max-h-48 rounded-2xl" />}
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button className="btn-primary">ផុស</button>
      </form>
    </Shell>
  );
}
