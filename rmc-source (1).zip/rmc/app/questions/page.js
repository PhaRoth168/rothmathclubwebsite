"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function QuestionsPage() {
  const [topics, setTopics] = useState([]);
  const [grades, setGrades] = useState([]);
  const [filters, setFilters] = useState({ topic: "", grade: "", q: "" });
  const [questions, setQuestions] = useState([]);

  useEffect(() => { api("bootstrap").then((d) => { setTopics(d.topics); setGrades(d.grades); }); }, []);
  useEffect(() => { api("questions", filters).then((d) => setQuestions(d.questions || [])); }, [filters]);

  return (
    <Shell>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">សហគមន៍សួរ-ឆ្លើយ</h1>
          <p className="text-sm text-slate-500">ផុសលំហាត់ ហើយបោះឆ្នោតចម្លើយល្អឱ្យឡើងលើ។</p>
        </div>
        <Link href="/ask" className="btn-primary">ផុសសំណួរ</Link>
      </div>
      <div className="mb-4 grid gap-2 md:grid-cols-3">
        <input className="field" placeholder="ស្វែងរក..." value={filters.q} onChange={(e) => setFilters({ ...filters, q: e.target.value })} />
        <select className="field" value={filters.topic} onChange={(e) => setFilters({ ...filters, topic: e.target.value })}>
          <option value="">គ្រប់ជំពូក</option>
          {topics.map((t) => <option key={t}>{t}</option>)}
        </select>
        <select className="field" value={filters.grade} onChange={(e) => setFilters({ ...filters, grade: e.target.value })}>
          <option value="">គ្រប់ថ្នាក់</option>
          {grades.map((g) => <option key={g}>{g}</option>)}
        </select>
      </div>
      <div className="space-y-3">
        {questions.map((q) => (
          <Link key={q.id} href={`/questions/${q.id}`} className="card block p-4">
            <div className="flex flex-wrap gap-2 text-xs"><span className="chip">{q.topic}</span><span className="chip">{q.grade}</span>{q.bestAnswerId && <span className="chip">🏅 មានចម្លើយល្អ</span>}</div>
            <h2 className="mt-2 text-lg font-semibold">{q.title}</h2>
            <p className="mt-1 line-clamp-2 text-sm text-slate-500">{q.body}</p>
            <div className="mt-2 text-xs text-slate-400">{q.author?.displayName} · {q.answerCount} ចម្លើយ</div>
          </Link>
        ))}
      </div>
    </Shell>
  );
}
