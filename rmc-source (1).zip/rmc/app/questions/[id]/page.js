"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell, { Avatar } from "../../../components/Shell";
import { api, fileToData } from "../../../lib/client";

export default function QuestionDetail({ params }) {
  const [question, setQuestion] = useState(null);
  const [body, setBody] = useState("");
  const [image, setImage] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const res = await api("question", { id: params.id });
    setQuestion(res.question || null);
  }
  useEffect(() => { load(); }, [params.id]);

  async function reply(e) {
    e.preventDefault();
    const res = await api("answer", { questionId: params.id, body, image });
    if (res.error) return setError(res.error);
    setBody(""); setImage(""); setQuestion(res.question);
  }

  async function vote(answerId, value) {
    const res = await api("vote", { answerId, value });
    if (res.error) return setError(res.error);
    setQuestion(res.question);
  }

  if (!question) return <Shell><p>កំពុងផ្ទុកសំណួរ...</p></Shell>;

  return (
    <Shell>
      <article className="card p-5">
        <div className="flex flex-wrap gap-2 text-xs"><span className="chip">{question.topic}</span><span className="chip">{question.grade}</span></div>
        <h1 className="mt-2 font-display text-3xl font-bold">{question.title}</h1>
        <p className="mt-3 whitespace-pre-wrap text-slate-700 dark:text-slate-200">{question.body}</p>
        {question.image && <img src={question.image} alt="លំហាត់" className="mt-3 max-h-80 rounded-2xl" />}
        <div className="mt-3 flex items-center gap-2 text-sm text-slate-500"><Avatar user={question.author} /> {question.author?.displayName}</div>
      </article>

      <section className="mt-5 space-y-3">
        <h2 className="font-display text-2xl font-bold">ចម្លើយ ({question.answers.length})</h2>
        {question.answers.map((a) => (
          <div key={a.id} className="card p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 text-sm"><Avatar user={a.author} /><span className="font-semibold">{a.author?.displayName}</span>{question.bestAnswerId === a.id && <span className="chip">🏅 Best Answer</span>}</div>
              <div className="flex items-center gap-1">
                <button className="btn-ghost !px-2" onClick={() => vote(a.id, 1)}>▲</button>
                <span className="w-6 text-center text-sm font-bold">{a.score}</span>
                <button className="btn-ghost !px-2" onClick={() => vote(a.id, -1)}>▼</button>
              </div>
            </div>
            <p className="mt-3 whitespace-pre-wrap">{a.body}</p>
            {a.image && <img src={a.image} alt="ចម្លើយ" className="mt-3 max-h-72 rounded-2xl" />}
          </div>
        ))}
      </section>

      <form onSubmit={reply} className="card mt-5 space-y-3 p-4">
        <h3 className="font-semibold">ឆ្លើយជាមួយវិធីដោះស្រាយ</h3>
        <textarea className="field min-h-28" placeholder="សរសេរជំហាន ឬរូបមន្ត" value={body} onChange={(e) => setBody(e.target.value)} />
        <input type="file" accept="image/*" onChange={async (e) => {
          try { setImage(await fileToData(e.target.files[0])); }
          catch { setError("រូបធំពេក"); }
        }} />
        {image && <img src={image} alt="" className="max-h-40 rounded-2xl" />}
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button className="btn-primary">ផ្ញើចម្លើយ</button>
        <p className="text-xs text-slate-500">ត្រូវ <Link href="/login" className="underline">ចូលគណនី</Link> ដើម្បីឆ្លើយ និងបោះឆ្នោត។</p>
      </form>
    </Shell>
  );
}
