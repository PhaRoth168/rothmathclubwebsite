"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Shell from "../components/Shell";
import { api } from "../lib/client";

export default function HomePage() {
  const [data, setData] = useState(null);
  useEffect(() => { api("bootstrap").then(setData); }, []);
  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;

  return (
    <Shell>
      <section className="card overflow-hidden p-6 md:p-10">
        <div className="grid items-center gap-8 md:grid-cols-[1.3fr_.7fr]">
          <div>
            <img src="/logo.png" alt="RothMath Junior" className="mb-4 h-24 w-auto rounded-2xl bg-white p-1" />
            <p className="chip inline-flex bg-amber-100 text-amber-800 dark:bg-amber-400/10 dark:text-amber-200">RothMath Junior · Learn · Think · Solve</p>
            <h1 className="mt-4 font-display text-4xl font-bold leading-tight md:text-5xl">រៀនគណិតវិទ្យាជាមួយគ្នា រាល់ថ្ងៃ</h1>
            <p className="mt-4 max-w-xl text-slate-600 dark:text-slate-300">ផុសលំហាត់ជាប់គាំង ឆ្លើយជាមួយមិត្តភក្តិ បង្កើតថ្នាក់និម្មិត និងរក្សា Streak ដោយគ្រាន់តែចូលរួមសកម្មភាពក្នុងថ្ងៃ។</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/ask" className="btn-primary">ផុសសំណួរ</Link>
              <Link href="/puzzles" className="btn-ghost">លេងប្រកួតថ្ងៃនេះ</Link>
              <Link href="/classrooms/new" className="btn-ghost">បង្កើតថ្នាក់</Link>
            </div>
          </div>
          <div className="rounded-3xl bg-blue-700 p-5 text-white">
            <div className="text-sm text-sky-100">Streak ថ្ងៃនេះ</div>
            <div className="mt-2 font-display text-5xl">🔥 {data.user ? data.user.streak : "—"}</div>
            <p className="mt-2 text-sm text-slate-300">{data.user ? "ចូលមើល ឬចូលរួមសកម្មភាពណាមួយ គឺរាប់ Streak។" : "ចូលគណនីដើម្បីចាប់ផ្តើម Streak។"}</p>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
              <Stat n={data.stats.members} l="សមាជិក" />
              <Stat n={data.stats.questions} l="សំណួរ" />
              <Stat n={data.stats.classrooms} l="ថ្នាក់" />
            </div>
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-4 md:grid-cols-3">
        {data.topClassrooms.map((c) => (
          <Link key={c.id} href={`/classrooms/${c.id}`} className="card overflow-hidden">
            <div className="relative h-24" style={{ background: String(c.cover).startsWith("linear") ? c.cover : undefined }}>
              {c.cover && !String(c.cover).startsWith("linear") && <img src={c.cover} alt="" className="h-full w-full object-cover" />}
            </div>
            <div className="p-4">
              <div className="font-semibold">{c.name}</div>
              <div className="mt-1 text-xs text-slate-500">{c.grade} · {c.memberCount} សមាជិក · ♥ {c.likeCount}</div>
            </div>
          </Link>
        ))}
      </section>

      <section className="mt-8 grid gap-4 md:grid-cols-[1.2fr_.8fr]">
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-2xl font-bold">សំណួរថ្មីៗ</h2>
            <Link href="/questions" className="text-sm text-indigo-600 dark:text-amber-300">មើលទាំងអស់</Link>
          </div>
          <div className="space-y-3">
            {data.recentQuestions.map((q) => (
              <Link key={q.id} href={`/questions/${q.id}`} className="card block p-4">
                <div className="flex gap-2 text-xs"><span className="chip">{q.topic}</span><span className="chip">{q.grade}</span></div>
                <div className="mt-2 font-semibold">{q.title}</div>
                <div className="mt-1 text-sm text-slate-500">{q.author?.displayName} · {q.answerCount} ចម្លើយ</div>
              </Link>
            ))}
          </div>
        </div>
        <div className="card p-5">
          <h2 className="font-display text-2xl font-bold">Daily Challenge</h2>
          {data.puzzle ? (
            <>
              <p className="mt-3 text-slate-600 dark:text-slate-300">{data.puzzle.prompt}</p>
              <Link href="/puzzles" className="btn-primary mt-4">ឆ្លើយឥឡូវ</Link>
            </>
          ) : <p className="mt-3 text-sm">Admin មិនទាន់ដាក់សំណួរថ្ងៃនេះទេ។</p>}
          <div className="mt-6 space-y-2 text-sm text-slate-500">
            <p>🏅 ផ្លាកសញ្ញាស្វ័យប្រវត្តពេលជួយ និងរក្សា Streak</p>
            <p>🏫 បង្កើតថ្នាក់ ហើយចែក PDF, តំណ និងមេរៀន</p>
            <p>📊 តារាងចំណាត់ថ្នាក់ពេញលេញគ្រប់ប្រភេទ</p>
          </div>
        </div>
      </section>
    </Shell>
  );
}

function Stat({ n, l }) {
  return <div className="rounded-2xl bg-white/10 p-2"><div className="font-display text-lg">{n}</div><div className="text-slate-300">{l}</div></div>;
}
