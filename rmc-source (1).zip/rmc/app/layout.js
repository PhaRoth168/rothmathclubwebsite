import "./globals.css";

export const metadata = {
  title: "RothMath Junior",
  description: "RothMath Junior — Learn, Think, Solve. សហគមន៍គណិតវិទ្យាសម្រាប់ថ្នាក់ទី ១០, ១១, ១២ និងបាក់ឌុប"
};

export default function RootLayout({ children }) {
  return (
    <html lang="km" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/logo.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;500;600;700&family=Outfit:wght@500;650;750&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css" />
        <script dangerouslySetInnerHTML={{ __html: `try{if(localStorage.getItem('rmc-theme')==='dark'||(!localStorage.getItem('rmc-theme')&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}` }} />
      </head>
      <body className="font-sans text-slate-900 antialiased dark:text-slate-100">{children}</body>
    </html>
  );
}
