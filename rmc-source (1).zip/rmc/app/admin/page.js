"use client";

import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function AdminPage() {
  const [data, setData] = useState(null);
  const [form, setForm] = useState({
    title: "ប្រកួតថ្ងៃស្អែក",
    prompt: "",
    choices: ["", "", "", ""],
    answer: "",
    explanation: "",
    topic: "ពីជគណិត",
    grade: "ថ្នាក់ទី១២",
    day: ""
  });
  const [msg, setMsg] = useState("");

  useEffect(() => { api("admin").then(setData); }, []);

  async function save(e) {
    e.preventDefault();
    const res = await api("savePuzzle", form);
    setMsg(res.error || "បានបញ្ចូលសំណួរ");
    if (!res.error) api("admin").then(setData);
  }

  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;
  if (data.error) return <Shell><p>{data.error} ចូលជា admin@rothmath.club / admin123</p></Shell>;

  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">ផ្ទាំង Admin</h1>
      <form onSubmit={save} className="card mt-4 space-y-3 p-5">
        <h2 className="font-semibold">បញ្ចូល Daily Puzzle</h2>
        <input className="field" placeholder="ចំណងជើង" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <textarea className="field" placeholder="សំណួរ" value={form.prompt} onChange={(e) => setForm({ ...form, prompt: e.target.value })} />
        {form.choices.map((c, i) => (
          <input key={i} className="field" placeholder={`ជម្រើស ${i + 1}`} value={c} onChange={(e) => {
            const choices = form.choices.slice();
            choices[i] = e.target.value;
            setForm({ ...form, choices });
          }} />
        ))}
        <input className="field" placeholder="ចម្លើយត្រឹមត្រូវ (ត្រូវដូចជម្រើសមួយ)" value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })} />
        <input className="field" placeholder="ការពន្យល់" value={form.explanation} onChange={(e) => setForm({ ...form, explanation: e.target.value })} />
        <input className="field" type="date" value={form.day} onChange={(e) => setForm({ ...form, day: e.target.value })} />
        {msg && <p className="text-sm">{msg}</p>}
        <button className="btn-primary">រក្សាសំណួរ</button>
      </form>
      <section className="card mt-4 p-5">
        <h2 className="font-semibold">សំណួរប្រចាំថ្ងៃ</h2>
        {data.puzzles.map((p) => (
          <div key={p.id} className="mt-2 flex items-center justify-between gap-3 text-sm">
            <span>{p.day} · {p.prompt}</span>
            <button className="btn-ghost" onClick={async () => { await api("deletePuzzle", { id: p.id }); api("admin").then(setData); }}>លុប</button>
          </div>
        ))}
      </section>
      <section className="card mt-4 p-5">
        <h2 className="font-semibold">សមាជិក ({data.users.length})</h2>
        <ul className="mt-2 space-y-1 text-sm">
          {data.users.map((u) => <li key={u.id}>{u.displayName} · {u.email} · {u.role} · 🔥 {u.streak}</li>)}
        </ul>
      </section>
    </Shell>
  );
}
