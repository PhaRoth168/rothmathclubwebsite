"use client";

import Shell from "../../components/Shell";
import { AuthCard } from "../login/page";

export default function SignupPage() {
  return <Shell><AuthCard mode="signup" /></Shell>;
}
