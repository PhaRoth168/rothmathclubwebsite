"use client";

import { useEffect, useState } from "react";
import Shell from "../../components/Shell";
import { api } from "../../lib/client";

export default function PuzzlesPage() {
  const [data, setData] = useState(null);
  const [msg, setMsg] = useState({});

  function load() { api("puzzles").then(setData); }
  useEffect(load, []);

  async function choose(puzzleId, choice) {
    const res = await api("puzzleAttempt", { puzzleId, choice });
    setMsg((m) => ({ ...m, [puzzleId]: res.error || (res.correct ? `ត្រឹមត្រូវ! ${res.explanation || ""}` : `មិនទាន់ត្រូវ។ ${res.explanation || ""}`) }));
    load();
  }

  if (!data) return <Shell><p>កំពុងផ្ទុក...</p></Shell>;

  return (
    <Shell>
      <h1 className="font-display text-3xl font-bold">Daily Math Challenge</h1>
      <p className="mt-1 text-sm text-slate-500">សំណួររៀបចំដោយ Admin។ ការចូលរួមរាប់ Streak ទោះឆ្លើយមិនទាន់ត្រូវ។</p>
      <div className="mt-5 space-y-4">
        {data.puzzles.map((p) => (
          <article key={p.id} className="card p-5">
            <div className="flex flex-wrap gap-2 text-xs">
              <span className="chip">{p.day === data.today ? "ថ្ងៃនេះ" : p.day}</span>
              <span className="chip">{p.topic}</span>
              <span className="chip">{p.grade}</span>
              {p.solved && <span className="chip">✅ បានឆ្លើយត្រូវ</span>}
            </div>
            <h2 className="mt-2 text-xl font-semibold">{p.title}</h2>
            <p className="mt-2">{p.prompt}</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {p.choices.map((c) => (
                <button key={c} className="btn-ghost" onClick={() => choose(p.id, c)}>{c}</button>
              ))}
            </div>
            {msg[p.id] && <p className="mt-3 text-sm">{msg[p.id]}</p>}
            <p className="mt-2 text-xs text-slate-400">{p.attempts} នាក់បានព្យាយាម</p>
          </article>
        ))}
      </div>
    </Shell>
  );
}
