"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "../lib/client";

const links = [
  ["/", "ទំព័រដើម"],
  ["/questions", "សួរ-ឆ្លើយ"],
  ["/puzzles", "ប្រកួតប្រចាំថ្ងៃ"],
  ["/classrooms", "ថ្នាក់រៀន"],
  ["/leaderboards", "ចំណាត់ថ្នាក់"]
];

const roleLabel = { student: "សិស្ស", teacher: "គ្រូ", admin: "Admin" };

export default function Shell({ children }) {
  const path = usePathname();
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [open, setOpen] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [notes, setNotes] = useState([]);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
    api("bootstrap").then((d) => setUser(d.user));
    api("ping").then((d) => d.user && setUser(d.user));
  }, [path]);

  async function openNotes() {
    const next = !notesOpen;
    setNotesOpen(next);
    if (next) {
      const data = await api("notifications");
      setNotes(data.notifications || []);
      await api("readNotes");
      setUser((u) => u ? { ...u, unread: 0 } : u);
    }
  }

  function toggleTheme() {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("rmc-theme", next ? "dark" : "light");
    setDark(next);
  }

  async function logout() {
    await api("logout");
    setUser(null);
    router.push("/");
    router.refresh();
  }

  return (
    <div className="grid-bg min-h-screen">
      <header className="sticky top-0 z-40 border-b border-blue-100 bg-white/90 backdrop-blur-xl dark:border-white/10 dark:bg-[#07111f]/85">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link href="/" className="flex items-center gap-2">
            <img src="/logo.png" alt="RothMath Junior" className="h-12 w-auto rounded-xl bg-white object-contain" />
          </Link>
          <nav className="ml-3 hidden items-center gap-1 md:flex">
            {links.map(([href, label]) => (
              <Link key={href} href={href} className={`rounded-full px-3 py-1.5 text-sm ${path === href ? "bg-blue-600 text-white" : "text-blue-900/70 hover:bg-blue-50 dark:text-slate-300 dark:hover:bg-white/10"}`}>
                {label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {user && (
              <div className="relative">
                <button className="btn-ghost relative !px-3" onClick={openNotes} aria-label="ដំណឹង">🔔
                  {user.unread > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-blue-600 px-1 text-[10px] text-white">{user.unread}</span>}
                </button>
                {notesOpen && (
                  <div className="absolute right-0 z-50 mt-2 w-80 card p-2">
                    {notes.length === 0 && <p className="p-3 text-sm text-slate-500">មិនទាន់មានដំណឹង។</p>}
                    {notes.slice(0, 6).map((n) => (
                      <Link key={n.id} href={n.href || "/notifications"} onClick={() => setNotesOpen(false)} className="block rounded-2xl px-3 py-2 text-sm hover:bg-blue-50 dark:hover:bg-white/10">
                        {n.text}
                      </Link>
                    ))}
                    <Link href="/notifications" className="block px-3 py-2 text-xs text-blue-600" onClick={() => setNotesOpen(false)}>មើលទាំងអស់</Link>
                  </div>
                )}
              </div>
            )}
            <button className="btn-ghost !px-3" onClick={toggleTheme}>{dark ? "☀️" : "🌙"}</button>
            {user ? (
              <>
                <Link href="/profile" className="hidden items-center gap-2 rounded-full border border-blue-100 bg-white px-2 py-1 dark:border-white/10 dark:bg-white/5 sm:flex">
                  <Avatar user={user} />
                  <span className="max-w-28 truncate text-sm font-semibold">{user.displayName}</span>
                  <span className="text-xs text-blue-600">{roleLabel[user.role] || user.role}</span>
                  <span>🔥 {user.streak}</span>
                </Link>
                {user.role === "admin" && <Link href="/admin" className="btn-ghost hidden sm:inline-flex">Admin</Link>}
                <button className="btn-ghost" onClick={logout}>ចេញ</button>
              </>
            ) : (
              <>
                <Link href="/login" className="btn-ghost">ចូល</Link>
                <Link href="/signup" className="btn-primary">ចុះឈ្មោះ</Link>
              </>
            )}
            <button className="btn-ghost md:hidden" onClick={() => setOpen((v) => !v)}>ម៉ឺនុយ</button>
          </div>
        </div>
        {open && (
          <div className="flex flex-wrap gap-2 border-t border-blue-100 px-4 py-3 dark:border-white/10 md:hidden">
            {links.map(([href, label]) => <Link key={href} href={href} onClick={() => setOpen(false)} className="chip">{label}</Link>)}
          </div>
        )}
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      <footer className="border-t border-blue-100 px-4 py-8 text-center text-sm text-slate-500 dark:border-white/10">
        RothMath Junior · Learn · Think · Solve
      </footer>
    </div>
  );
}

export function Avatar({ user, size = "h-8 w-8" }) {
  if (user?.avatar) return <img src={user.avatar} alt="" className={`${size} rounded-full object-cover`} />;
  const letter = (user?.displayName || "?").trim().charAt(0);
  return <span className={`${size} grid place-items-center rounded-full bg-blue-600 text-xs font-bold text-white`}>{letter}</span>;
}
