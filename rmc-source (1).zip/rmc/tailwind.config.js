/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["Noto Sans Khmer", "Outfit", "system-ui", "sans-serif"],
        display: ["Outfit", "Noto Sans Khmer", "sans-serif"]
      },
      colors: {
        ink: "#0b1020",
        amberglow: "#f5b942"
      },
      boxShadow: {
        glow: "0 0 40px rgba(245, 185, 66, 0.18)"
      }
    }
  },
  plugins: []
};
