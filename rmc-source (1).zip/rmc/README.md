# RothMath Junior / Roth Math Club

សហគមន៍គណិតវិទ្យា Next.js + Tailwind។ ពណ៌ចម្បងខៀវ និងស, មាន Dark/Light mode។

## តួនាទី

- សិស្ស: សួរ, ឆ្លើយ, Streak, ចូលថ្នាក់
- គ្រូ: បង្កើត និងគ្រប់គ្រងថ្នាក់ (កម្រិតថ្នាក់សរសេរដោយសេរី, logo និងរូបគម្រប)
- Admin: ផ្ទាំង `/admin` សម្រាប់បង្កើត កែ និងលុប Daily Challenge។ មិនអាចចុះឈ្មោះ Admin ពីទម្រង់សាធារណៈ

## គណនីសាកល្បង

- Admin: `admin@rothmath.club` / `admin123`
- គ្រូ: `rathana@student.rmc` / `math123`
- សិស្ស: `sothy@student.rmc` / `math123`

## ដំណើរការ

```bash
cd rmc
npm install
npm run dev
```

បើក http://localhost:3000

បើទិន្នន័យចាស់នៅឡើយ សូមលុប `data/db.json` ម្តង ដើម្បីផ្ទុកទិន្នន័យសាកល្បងថ្មី។

## ដាក់ឱ្យដំណើរការ

1. កំណត់ `SESSION_SECRET`។
2. `npm install && npm run build && npm start`
3. VPS ឬ Railway សមស្របជាង Vercel/Netlify ព្រោះ `data/db.json` ត្រូវសរសេរបាន។
4. លើ Netlify មាន `netlify.toml` ស្រាប់។ រត់ `npx netlify-cli deploy --build --prod` បន្ទាប់ពីចូលគណនី។ ទិន្នន័យឯកសារមិននៅអចិន្ត្រៃយ៍លើ serverless។
